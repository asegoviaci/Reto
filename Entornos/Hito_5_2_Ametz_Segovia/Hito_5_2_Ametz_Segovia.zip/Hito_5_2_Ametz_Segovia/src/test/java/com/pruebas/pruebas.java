package com.pruebas;

import com.example.demo.service.SmartPhoneServiceImpl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class pruebas {
    @BeforeAll
    public void pruebaBefore() {
        System.out.println("Inicio");
    }
    @Test
    @Order(2)
    public void testCount(){
        SmartPhoneServiceImpl s1 = new SmartPhoneServiceImpl();
        assertAll(() -> assertNotNull(s1.count(),"Este valor es nulo"));
        assertAll(() -> assertTrue(s1.count() > 0, "Este numero debe ser mayor que 0"));
        assertAll(() ->assertEquals(3, s1.count(),"El numero debe ser 3"));
        System.out.println("1");
    }
   /*
    public void testCount(){
            SmartPhoneServiceImpl s1 = new SmartPhoneServiceImpl();
            Assertions.assertNotNull(s1.count(),"No NULL");
            Assertions.assertTrue(s1.count() > 0, "Mayor que 0");
            Assertions.assertEquals(3, s1.count(),"3");
    }
    */
    @Test
    @Order(1)
    public void testFindOne(){
        SmartPhoneServiceImpl s1 = new SmartPhoneServiceImpl();
        Long id = null;
        assertThrows(IllegalArgumentException.class, () -> {
            s1.findOne(id);
        });
        System.out.println("2");
    }
    @AfterAll
    public void ending() {
        System.out.println("Final");
    }
}
