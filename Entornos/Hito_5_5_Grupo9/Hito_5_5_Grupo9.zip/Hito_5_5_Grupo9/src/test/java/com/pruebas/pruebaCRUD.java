package com.pruebas;

import Controlers.IDB;
import DB_management.Conexion;
import Modelos.*;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Nested;

import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.border.EmptyBorder;
import java.security.*;
@Nested
public class pruebaCRUD {
    @Test
    public void pruebacrearpiloto() {
        Assertions.assertNotNull(new Piloto(1, "Juan", "Aereo", "piloto", "10", "16:00", 2000, "Zubiri123", 10));
    }
    @Test
    public void pruebacrearcliente() {
        Assertions.assertNotNull(new Cliente("05752043L", "Teri", "Stainer", 688952594, "tsteinero@miibeian.gov.cn", "cdca39b6089d200e8907ce09a5603cb3ff736b2e952fd35d466d0892c4447f4b"));
    }
    @Test
    public void pruebaleerpiloto() {
        Piloto p1 = new Piloto(1, "Juan", "Aereo", "piloto", "10", "16:00", 2000, "Zubiri123", 10);
        Assertions.assertEquals(p1.getNombre(),"Juan");
    }
    @Test
    public void pruebaleercliente() {
        Cliente cliente = new Cliente("05752043L", "Teri", "Stainer", 688952594, "tsteinero@miibeian.gov.cn", "cdca39b6089d200e8907ce09a5603cb3ff736b2e952fd35d466d0892c4447f4b");
        Assertions.assertEquals(cliente.getNombre(),"Teri");
    }
    @Test
    public void prubacambiarpiloto() {
        Piloto p1 = new Piloto(1, "Juan", "Aereo", "piloto", "10", "16:00", 2000, "Zubiri123", 10);
        p1.setNombre("Juan1");
        Assertions.assertEquals(p1.getNombre(),"Juan1");
    }
    @Test
    public void pruebacambiarcliente() {
        Cliente cliente = new Cliente("05752043L", "Teri", "Stainer", 688952594, "tsteinero@miibeian.gov.cn", "cdca39b6089d200e8907ce09a5603cb3ff736b2e952fd35d466d0892c4447f4b");
        cliente.setNombre("Teri1");
        Assertions.assertEquals(cliente.getNombre(),"Teri1");
    }
    @Test
    public void Pruebaeliminarpiloto() {
        Piloto p1 = new Piloto(1, "Juan", "Aereo", "piloto", "10", "16:00", 2000, "Zubiri123", 10);
        p1 = null;
        Assertions.assertNull(p1);
    }
    @Test
    public void pruebaeliminarcliente() {
        Cliente cliente = new Cliente("05752043L", "Teri", "Stainer", 688952594, "tsteinero@miibeian.gov.cn", "cdca39b6089d200e8907ce09a5603cb3ff736b2e952fd35d466d0892c4447f4b");
        cliente = null;
        Assertions.assertNull(cliente);
    }
}