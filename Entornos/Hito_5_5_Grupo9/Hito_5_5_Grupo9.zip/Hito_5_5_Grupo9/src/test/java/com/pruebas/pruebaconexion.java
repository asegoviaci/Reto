package com.pruebas;

import static org.junit.jupiter.api.Assertions.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import DB_management.Conexion;
import Modelos.Cliente;
import Modelos.Piloto;
import Windows.*;
import org.junit.Test;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class pruebaconexion {
    @Test
    @RepeatedTest(3)
    public void prueba_sesion() {
        String resultado="cdca39b6089d200e8907ce09a5603cb3ff736b2e952fd35d466d0892c4447f4b";
        String contraseña = "Zubiri123";
        String contraseña2 = "si123";
        Assertions.assertEquals(Inicio_de_sesion.getHashedPassword(contraseña),resultado);
    }
    @Test
    public void pruebaContFilas() {
        Conexion conexion = new Conexion();
        int numFilas = Inicio_de_sesion.Contfilas(conexion);
        assertEquals(46, numFilas);
    }
    @Test
    @EnabledOnOs(OS.WINDOWS)
    public void pruebaWindows() {
        Assertions.assertTrue(true);
    }
    @Test
    @BeforeAll
    public void pruebadriver() {
        Conexion con = new Conexion();
        Assertions.assertNotNull(con);
    }
    @Test
    public void PruebaHash(){
        String contraseña= "Zubiri123";
        String hash="cdca39b6089d200e8907ce09a5603cb3ff736b2e952fd35d466d0892c4447f4b";
        assertEquals(hash, Inicio_de_sesion.getHashedPassword(contraseña));
    }
    @Test
    public void Pruebavuelos(){
        Conexion conexion = new Conexion();
        String[] Columnas = {"Avion", "Id_vuelo", "Origen", "Destino", "Salida", "Llegada", "Precio"};
        String[][] vuelos = Inicio_de_sesion.Mostrarvuelos(conexion,Columnas);
        Assertions.assertNotNull(vuelos);
    }
    @Test
    public void Pruebapasajes(){
        Conexion conexion = new Conexion();
        Cliente cliente = new Cliente("05752043L", "Teri", "Stainer", 688952594, "tsteinero@miibeian.gov.cn", "cdca39b6089d200e8907ce09a5603cb3ff736b2e952fd35d466d0892c4447f4b");
        String[] Columnas = {"Avion", "Origen", "Destino", "Salida", "Llegada", "Precio"};
        String[][] pasajes = InicioClientes.Mostrarpasajes(conexion,Columnas,cliente);
        Assertions.assertNotNull(pasajes);
    }
    @Test
    public void Pruebacerrarsesion(){
        Cliente cliente = new Cliente("05752043L", "Teri", "Stainer", 688952594, "tsteinero@miibeian.gov.cn", "cdca39b6089d200e8907ce09a5603cb3ff736b2e952fd35d466d0892c4447f4b");
        cliente = null;
        Assertions.assertNull(cliente);
    }
    @Test
    public void PruebacontVuelospiloto(){
        Conexion conexion = new Conexion();
        Piloto piloto = new Piloto(99, "Tiffi", "Braiden", "piloto", "6:35", "16:30", 3291, "cdca39b6089d200e8907ce09a5603cb3ff736b2e952fd35d466d0892c4447f4b",2);
        int cant = InicioPiloto.Contfilas_vuelos_propios(conexion,piloto);
        Assertions.assertEquals(2, cant);
    }
    @Test
    public void Pruebavuelospiloto(){
        Conexion conexion = new Conexion();
        Piloto piloto = new Piloto(99, "Tiffi", "Braiden", "piloto", "6:35", "16:30", 3291, "cdca39b6089d200e8907ce09a5603cb3ff736b2e952fd35d466d0892c4447f4b",2);
        String[] Columnas = {"Avion", "Id_vuelo", "Origen", "Destino", "Salida", "Llegada"};
        String[][] vuelos = InicioPiloto.Mostrar_mis_vuelos(conexion,Columnas,piloto);
        Assertions.assertNotNull(vuelos);
    }
    @Test
    public void Pruebamostrarpasajes(){
        Conexion conexion = new Conexion();
        int id_vuelo = 3;
        String[] Columnas_pasajes = {"Id pasaje", "Id vuelo", "Clase", "Asiento", "Precio", "DNI"};
        String[][] pasajes = InicioRecepcion.MostrarPasajes(conexion,id_vuelo,Columnas_pasajes);
        Assertions.assertNotNull(pasajes);
    }
    @Test
    public void Pruebacontpasajes(){
        Conexion conexion = new Conexion();
        int id_vuelo = 3;
        int cant = InicioRecepcion.Contfilas_Pasaje(conexion,id_vuelo);
        Assertions.assertEquals(5, cant);
    }
}