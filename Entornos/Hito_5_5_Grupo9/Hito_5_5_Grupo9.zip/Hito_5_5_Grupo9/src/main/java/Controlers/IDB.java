package Controlers;

public interface IDB {

}
