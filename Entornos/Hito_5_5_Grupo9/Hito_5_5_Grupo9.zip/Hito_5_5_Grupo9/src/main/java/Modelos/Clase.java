package Modelos;

public enum Clase {
    Primera, Ejecutiva, Premium, Turista
}
